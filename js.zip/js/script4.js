var box = document.querySelector(".box");
var btn = document.querySelector(".btn");
var main = document.querySelector(".main");
var all = document.querySelector(".all");



var container = "";

main.addEventListener("click", function () {
  var color1 = Math.floor(Math.random() * 256);
  var color2 = Math.floor(Math.random() * 256);
  var color3 = Math.floor(Math.random() * 256);
  var num = Math.floor(Math.random() *10);

  container += `<div class="box w-60 h-72 ${color1,color2,color3} m-14"></div>
        <button class="btn bg-blue-500 p-4 rounded-xl ml-14">${num}</button>`;
      document.querySelector(".bubbles").innerHTML = container;
});
