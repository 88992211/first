let currentSongIndex = 0;
let isPlaying = false;

const songs = [
    {
        title: 'Song 1',
        artist: 'Artist 1',
        albumArt: 'album-art1.jpg',
        src: 'song1.mp3'
    },
    {
        title: 'Song 2',
        artist: 'Artist 2',
        albumArt: 'album-art2.jpg',
        src: 'song2.mp3'
    },
    // Add more songs as needed
];

const audio = new Audio(songs[currentSongIndex].src);

const albumArt = document.getElementById('albumArt');
const songTitle = document.getElementById('songTitle');
const artistName = document.getElementById('artistName');
const playPauseBtn = document.getElementById('playPauseBtn');
const volumeSlider = document.getElementById('volumeSlider');

function loadSong(song) {
    albumArt.src = song.albumArt;
    songTitle.textContent = song.title;
    artistName.textContent = song.artist;
    audio.src = song.src;
}

function togglePlayPause() {
    if (isPlaying) {
        audio.pause();
        playPauseBtn.textContent = '►';
    } else {
        audio.play();
        playPauseBtn.textContent = '❚❚';
    }
    isPlaying = !isPlaying;
}

function nextSong() {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    loadSong(songs[currentSongIndex]);
    if (isPlaying) {
        audio.play();
    }
}

function prevSong() {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    loadSong(songs[currentSongIndex]);
    if (isPlaying) {
        audio.play();
    }
}

function setVolume(volume) {
    audio.volume = volume;
}

// Initialize the first song
loadSong(songs[currentSongIndex]);

// Event listeners for audio
audio.addEventListener('ended', nextSong);
