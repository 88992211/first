function generateOtp() {
    var digits = "0123456789";
    var otp = "";
    for (var i = 0; i<4; i++) {
        otp += digits[Math.floor(Math.random() * 10)];
    }
    document.getElementById("box").innerHTML = otp;
}
