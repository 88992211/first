

var contanier =""
for(var i=0; i<200; i++){
   var red = Math.floor(Math.random()* 256);
   var blue = Math.floor(Math.random()* 256)
   var green = Math.floor(Math.random()* 256)

   var num = Math.floor(Math.random()*200)

    contanier +=`<div style="background-color:rgb(${red},${green},${blue});"
    class="bubble  flex items-center justify-center w-14 h-14  p-5 rounded-full">${num}</div>`
}

document.querySelector(".bubbles").innerHTML = contanier;