var main = document.querySelector(".main");

var btn = document.createElement("button");
btn.textContent = "get start";
btn.classList.add("btn");

btn.addEventListener("click", function () {
    var color1 = Math.floor(Math.random() * 256);
    var color2 = Math.floor(Math.random() * 256);
    var color3 = Math.floor(Math.random() * 256);

    var box = document.createElement("div");
    box.classList.add("box", "w-60", "h-60");
    box.style.backgroundColor = rgb(${color1},${color2},${color3});

    main.appendChild(box);
});

main.appendChild(btn);