class SecuritySettings {
    constructor(passwordManager, twoFactorAuth, dataEncryption, appPermissions) {
        this.passwordManager = passwordManager;
        this.twoFactorAuth = twoFactorAuth;
        this.dataEncryption = dataEncryption;
        this.appPermissions = appPermissions;
    }

    enableTwoFactorAuth() {
        this.twoFactorAuth = true;
        console.log('Two-Factor Authentication Enabled');
        alert('Two-Factor Authentication Enabled');
    }

    disableTwoFactorAuth() {
        this.twoFactorAuth = false;
        console.log('Two-Factor Authentication Disabled');
        alert('Two-Factor Authentication Disabled');
    }
}

class GameSettings {
    constructor(difficulty, graphics, sound, controls, accessibility) {
        this.difficulty = difficulty;
        this.graphics = graphics;
        this.sound = sound;
        this.controls = controls;
        this.accessibility = accessibility;
    }

    setDifficulty(level) {
        this.difficulty = level;
        console.log('Difficulty set to', level);
        alert('Difficulty set to ' + level);
    }

    adjustGraphics(resolution, textureQuality) {
        this.graphics = { resolution: resolution, textureQuality: textureQuality };
        console.log('Graphics set to', this.graphics);
        alert('Graphics set to resolution: ' + resolution + ', texture quality: ' + textureQuality);
    }
}

class DisplayModeSettings {
    constructor(mode = 'light', schedule = null) {
        this.mode = mode;
        this.schedule = schedule;
    }

    switchMode() {
        this.mode = (this.mode === 'light') ? 'dark' : 'light';
        console.log('Display mode switched to', this.mode);
        alert('Display mode switched to ' + this.mode);
    }
}

class SystemSettings {
    constructor(sound, notifications, screenTime, wifi) {
        this.sound = sound;
        this.notifications = notifications;
        this.screenTime = screenTime;
        this.wifi = wifi;
    }

    adjustSound(volume, profile) {
        this.sound = { volume: volume, profile: profile };
        console.log('Sound adjusted to', this.sound);
        alert('Sound adjusted to volume: ' + volume + ', profile: ' + profile);
    }
}

// Initialize settings
const securitySettings = new SecuritySettings('LastPass', false, true, ['Camera', 'Location']);
const gameSettings = new GameSettings('Medium', { resolution: '1080p', textureQuality: 'High' }, { musicVolume: 80, effectsVolume: 70 }, 'Default', { subtitles: true });
const displayModeSettings = new DisplayModeSettings();
const systemSettings = new SystemSettings({ volume: 50, profile: 'Normal' }, { appNotifications: true, doNotDisturb: false }, '4 hours', { network: 'MyWiFi', security: 'WPA2' });
