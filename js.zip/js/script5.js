var teams = ["mi","rcb","crk","krk","lal",];
var colors = ["blue","red","yellow","zinc","black"];

var btn = document.querySelector(".btn");
var main = document.querySelector(".main");
var winner = document.querySelector(".winner");

btn.addEventListener("click",function(){
   var random = Math.floor(Math.random()*teams.length)

  winner.innerHTML = teams[random];
  main.style.backgroundColor = colors[random];


})

